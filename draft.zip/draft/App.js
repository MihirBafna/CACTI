import * as React from 'react';
import { Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Image,  StyleSheet} from 'react-native';
import RangeSlider, { Slider } from 'react-native-range-slider-expo';
import { useState } from 'react';


function HomeScreen() {
  return (
    <View style={styles.container}>
      <Image source={{ uri: "https://d1gntqhqj0rbcs.cloudfront.net/assets/82/GATech_Adjusted-03-25-2020/16/17403/39307" }} style={{ width: 350, height: 500 }} />
    
      <Text style={{color: '#888', fontSize: 18}}> 
        This will follow and update live with user movement
      </Text>
    </View>
  );
}

function AnalysisScreen() {
     const [fromValue, setFromValue] = useState(0);
     const [toValue, setToValue] = useState(0);
     const [value, setValue] = useState(0);
     return (
           
          <View style={styles.container}>
          <View>
            <Image source={{ uri: "https://d1gntqhqj0rbcs.cloudfront.net/assets/82/GATech_Adjusted-03-25-2020/16/17403/39307" }} style={{ width: 350, height: 300 }} /> </View>
               <View>
                    <Text>Minimum # bluetooth connections per phone</Text>
                    <RangeSlider min={5} max={100}
                         fromValueOnChange={value => setFromValue(value)}
                         toValueOnChange={value => setToValue(value)}
                         initialFromValue={5}
                         knobColor='grey'
                         valueLabelsBackgroundColor='black'
                         styleSize = 'small'
                    />
               </View>
               <View>
                    <Text>Time</Text>
                    <Slider min={0} max={24} step={.5}
                         fromValueOnChange={value => setFromValue(value)}
                         toValueOnChange={value => setToValue(value)}
                         initialFromValue={5}
                         knobColor='grey'
                         valueLabelsBackgroundColor='black'
                         styleSize = 'small'
                    />
               </View>
          </View>
     );
}
function AccountScreen() {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Permissions, Pseudonym, History, etc.</Text>
    </View>
  );
}
const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Live" component={HomeScreen} />
        <Tab.Screen name="Analysis" component={AnalysisScreen} />
        <Tab.Screen name="Account" component={AccountScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
<Slider
    style={{width: 200, height: 40}}
    minimumValue={0}
    maximumValue={1}
    minimumTrackTintColor="#FFFFFF"
    maximumTrackTintColor="#000000"
  />